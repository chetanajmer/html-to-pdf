<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src=
"https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js">
  </script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <div class="header">
          <div class="logo-box photologo">
             <img src="cibil-logo.jpg">
          </div>
          <div class="title-box">
            <p>CONSUMER CIR</p>
          </div>
          <div class="info-box">
            <div class="row">
              <div class="col-sm-6">
                <span class="fadeta">CUSTOMER:</span>
                <span class="faresul">ROHIT KUMAR VERMA</span><br>
                <span class="fadeta">MEMBER ID:</span>
                <span class="faresul">ROHIT KUMAR VERMA</span><br>
                <span class="fadeta">MEMBER REFERENCE NUMBER:</span>
                 <span class="faresul">52525525</span>
              </div>
               <div class="col-sm-6 colsec">
                <span class="fadeta">DATE :</span>
                <span class="faresul">30-04-2024</span><br>
                <span class="fadeta">TIME :</span>
                <span class="faresul">16-16-2024</span><br>
                <span class="fadeta">CONTROL NUMBER :</span>
                 <span class="faresul">5454545</span>
              </div>
            </div>
          </div>
          <hr class="hrlink">
        </div>
      </div>
      <div class="col-sm-12">
        <div class="customer-detail-box">
          <h5>CONSUMER INFORMATION</h5>
          <span class="cispan">NAME :</span>
          <span class="faresul">MR ROHITASHVA</span><br>
           <span class="cispan">DATE OF BIRTH :</span>
          <span class="faresul">01-06-1992</span>
          <span id="gender" class="cispan">GENDER :</span>
          <span class="faresul">MALE</span>
        </div>
      </div>
       <hr class="cihr">
         <div class="col-sm-12">
        <div class="customer-detail-box">
          <h5>SCORE NAME :</h5>
         <div class="row">
           <div class="col-sm-2">
             <p>SCORE NAME</p>
           </div>
           <div class="col-sm-1">
             <p>SCORE</p>
           </div>
           <div class="col-sm-9">
             <p>SCORING FACTORS</p>
           </div>
         </div>
        </div>
      </div>
        <div class="col-sm-12" style="background-color:silver">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-2">
             <p>CREDITVISION@ SCORE</p>
           </div>
           <div class="col-sm-1">
             <p>SCORE</p>
           </div>
           <div class="col-sm-9">
             <p>SCORING FACTORS</p>
           </div>
         </div>
        </div>
      </div>
        <hr style="background-color: gray;height: 2px;margin-top: 20px;">
         <div class="col-sm-12" style="background-color:silver">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-12">
             <p>POSSIBLE RANGE FOR CREDITVISION,type &reg;</p>
           </div>
           <div class="col-sm-6">
             <p>Consumer with at least one trade on the bureau in last 36 months </p>
             <p>Consumer not in CIBIL database or history older than 36 months</p>
           </div>
           <div class="col-sm-6">
             <p>: 300 (High risk) to 900 (low risk)</p>
             <p>: -1</p>
           </div>
           <div class="col-sm-12">
             <span>* At least one tradeline with information updated in last 36 months is required</span>
           </div>
         </div>
        </div>
      </div>
       <div class="col-sm-12">
        <div class="customer-detail-box">
          <h5>IDENTIFICATION(S):</h5>
         <div class="row">
           <div class="col-sm-3">
             <p>IDENTIFICATION TYPE</p>
           </div>
           <div class="col-sm-3">
             <p>IDENTIFICATION NUMBER</p>
           </div>
           <div class="col-sm-3">
             <p>ISSUE DATE</p>
           </div>
            <div class="col-sm-3">
             <p>EXPIRATION DATE</p>
           </div>
         </div>
        </div>
      </div>
       <div class="col-sm-12" style="background-color:silver">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-3">
             <p>INCOME TAX ID NUMBER (PAN)</p>
           </div>
           <div class="col-sm-3">
             <p>AVQPG0606F</p>
           </div>
           <div class="col-sm-3">
             <p>AVQPG0606F</p>
           </div>
           <div class="col-sm-3">
             <p>AVQPG0606F</p>
           </div>
          
         </div>
        </div>
      </div>
       <div class="col-sm-12">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-3">
             <p>VOTER ID NUMBER</p>
           </div>
           <div class="col-sm-3">
             <p>XVO/0563684</p>
           </div>
           <div class="col-sm-3">
             <p>AVQPG0606F</p>
           </div>
           <div class="col-sm-3">
             <p>AVQPG0606F</p>
           </div>
          
         </div>
        </div>
      </div>
        <hr style="background-color: gray;height: 2px;margin-top: 20px;">

        <div class="col-sm-12">
        <div class="customer-detail-box">
          <h5>TELEPHONE(S):</h5>
         <div class="row">
           <div class="col-sm-4">
             <p>TELEPHONE TYPE</p>
           </div>
           <div class="col-sm-4">
             <p>TELEPHONE NUMBER</p>
           </div>
           <div class="col-sm-4">
             <p>TELEPHONE EXTENSION</p>
           </div>
            
         </div>
        </div>
      </div>

<div class="col-sm-12" style="background-color:silver">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-4">
             <p>INCOME TAX ID NUMBER (PAN)</p>
           </div>
           <div class="col-sm-4">
             <p>AVQPG0606F</p>
           </div>
           <div class="col-sm-4">
             <p>AVQPG0606F</p>
           </div>
        
          
         </div>
        </div>
      </div>
<div class="col-sm-12">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-4">
             <p>INCOME TAX ID NUMBER (PAN)</p>
           </div>
           <div class="col-sm-4">
             <p>AVQPG0606F</p>
           </div>
           <div class="col-sm-4">
             <p>AVQPG0606F</p>
           </div>
        
          
         </div>
        </div>
      </div>
      <div class="col-sm-12" style="background-color:silver">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-4">
             <p>INCOME TAX ID NUMBER (PAN)</p>
           </div>
           <div class="col-sm-4">
             <p>AVQPG0606F</p>
           </div>
           <div class="col-sm-4">
             <p>AVQPG0606F</p>
           </div>
        
          
         </div>
        </div>
      </div>
        <hr style="background-color: gray;height: 2px;margin-top: 20px;">

        <div class="col-sm-12">
        <div class="customer-detail-box">
          <h5>EMAIL CONTACT(S):</h5>
          <span>EMAIL ADDRESS</span>
         <div class="row">
          <div class="col-sm-12" style="background-color:silver">
              <p>ROHITGADHWAL@GMAIL.COM</p>
          </div>
             <div class="col-sm-12">
              <p>ROHITGADHWAL@HOT.COM</p>
          </div>
         </div>
        </div>
      </div>
        <hr style="background-color: gray;height: 2px;margin-top: 20px;">
<!-- Address Repeatation -->
        <div class="col-sm-12" style="background-color:lightgray;border-bottom: 2px solid gray;z-index: 999;margin-top: 20px;">
        <div class="customer-detail-box">
      
         <div class="row">
           <div class="col-sm-12">
          <span>Address</span>
          <span>S/O RAJENDRA KUMAR GADHWAL GADHWALO KI DHANI GAON GAURI KA BAS TEHSIL CHOMU DOONGRI KHURD JAIPUR
RAJASTHAN TEHSIL-CHOMU 303603 RAJASTHAN 303603
</span>
           </div>
        
            
         </div>

         <div class="row">
           <div class="col-sm-4">
             <span style="color:#1273a8;">CATEGORY :</span>
             <span>RESIDENCE ADDRESS</span>
           </div>
            <div class="col-sm-4">
             <span style="color:#1273a8;">RESIDENCE CODE:</span>
             <span></span>
           </div>
            <div class="col-sm-4">
             <span style="color:#1273a8;">DATE REPORTED :</span>
             <span>31-03-2024</span>
           </div>
         </div>

        </div>
      </div>
  <div class="col-sm-12" style="border-bottom: 2px solid gray;z-index: 999;margin-top: 20px;">
        <div class="customer-detail-box">
      
         <div class="row">
           <div class="col-sm-12">
          <span>Address</span>
          <span>S/O RAJENDRA KUMAR GADHWAL GADHWALO KI DHANI GAON GAURI KA BAS TEHSIL CHOMU DOONGRI KHURD JAIPUR
RAJASTHAN TEHSIL-CHOMU 303603 RAJASTHAN 303603
</span>
           </div>
        
            
         </div>

         <div class="row">
           <div class="col-sm-4">
             <span style="color:#1273a8;">CATEGORY :</span>
             <span>RESIDENCE ADDRESS</span>
           </div>
            <div class="col-sm-4">
             <span style="color:#1273a8;">RESIDENCE CODE:</span>
             <span></span>
           </div>
            <div class="col-sm-4">
             <span style="color:#1273a8;">DATE REPORTED :</span>
             <span>31-03-2024</span>
           </div>
         </div>

        </div>
      </div>
  <div class="col-sm-12" style="background-color:lightgray;border-bottom: 2px solid gray;z-index: 999;margin-top: 20px;">
        <div class="customer-detail-box">
      
         <div class="row">
           <div class="col-sm-12">
          <span>Address</span>
          <span>S/O RAJENDRA KUMAR GADHWAL GADHWALO KI DHANI GAON GAURI KA BAS TEHSIL CHOMU DOONGRI KHURD JAIPUR
RAJASTHAN TEHSIL-CHOMU 303603 RAJASTHAN 303603
</span>
           </div>
        
            
         </div>

         <div class="row">
           <div class="col-sm-4">
             <span style="color:#1273a8;">CATEGORY :</span>
             <span>RESIDENCE ADDRESS</span>
           </div>
            <div class="col-sm-4">
             <span style="color:#1273a8;">RESIDENCE CODE:</span>
             <span></span>
           </div>
            <div class="col-sm-4">
             <span style="color:#1273a8;">DATE REPORTED :</span>
             <span>31-03-2024</span>
           </div>
         </div>

        </div>
      </div>
        <div class="col-sm-12" style="border-bottom: 2px solid gray;z-index: 999;margin-top: 20px;">
        <div class="customer-detail-box">
      
         <div class="row">
           <div class="col-sm-12">
          <span>Address</span>
          <span>S/O RAJENDRA KUMAR GADHWAL GADHWALO KI DHANI GAON GAURI KA BAS TEHSIL CHOMU DOONGRI KHURD JAIPUR
RAJASTHAN TEHSIL-CHOMU 303603 RAJASTHAN 303603
</span>
           </div>
        
            
         </div>

         <div class="row">
           <div class="col-sm-4">
             <span style="color:#1273a8;">CATEGORY :</span>
             <span>RESIDENCE ADDRESS</span>
           </div>
            <div class="col-sm-4">
             <span style="color:#1273a8;">RESIDENCE CODE:</span>
             <span></span>
           </div>
            <div class="col-sm-4">
             <span style="color:#1273a8;">DATE REPORTED :</span>
             <span>31-03-2024</span>
           </div>
         </div>

        </div>
      </div>
       <hr style="background-color: gray;height: 2px;margin-top: 30px;">


        <div class="col-sm-12">
        <div class="customer-detail-box">
          <h5>EMPLOYMENT INFORMATION:</h5>
         <div class="row">
           <div class="col-sm-2">
             <p>ACCOUNT TYPE</p>
           </div>
          <div class="col-sm-2">
             <p>DATE <br>REPORTED</p>
           </div>
            <div class="col-sm-2">
             <p>OCCUPATION CODE</p>
           </div>
            <div class="col-sm-2">
             <p>INCOME</p>
           </div>
            <div class="col-sm-2">
             <p>NET / GROSS INCOME<br>INDICATOR</p>
           </div>
            <div class="col-sm-2">
             <p>MONTHLY / ANNUAL<br>INCOME INDICATOR</p>
           </div>
            
         </div>
        </div>
      </div>

<div class="col-sm-12" style="background-color:silver">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-2">
             <p>CONSUMER LOAN</p>
           </div>
           <div class="col-sm-2">
             <p>31-03-2024</p>
           </div>
           <div class="col-sm-2">
             <p>OTHERS</p>
           </div>
           <div class="col-sm-2">
             <p>Not Available</p>
           </div>
           <div class="col-sm-2">
             <p>Not Available</p>
           </div>
           <div class="col-sm-2">
             <p>Not Available</p>
           </div>
        
          
         </div>
        </div>
      </div>

        <div class="col-sm-12">
        <div class="customer-detail-box">
          <h5>SUMMARY:</h5>
          <p>ACCOUNT(S)</p>
         <div class="row">
           <div class="col-sm-2">
             <p>ACCOUNT TYPE</p>
           </div>
          <div class="col-sm-2" style="text-align: right;padding-right: 30px;">
             <p>ACCOUNTS</p>
           </div>
            <div class="col-sm-3" style="text-align: right;padding-right: 30px;">
             <p>ADVANCES</p>
           </div>
            <div class="col-sm-3" style="text-align: right;padding-right: 30px;">
             <p>BALANCES</p>
           </div>
            <div class="col-sm-2" style="text-align: right;padding-right: 30px;">
             <p>DATE OPENED</p>
           </div>
          
            
         </div>
        </div>
      </div>


<div class="col-sm-12" style="background-color:silver">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-2">
             <p>All Accounts</p>
           </div>
           <div class="col-sm-2">
             <div class="row">
               <div class="col-sm-12 allaccount">
                 <span>TOTAL: 15</span>
               </div>
               <div class="col-sm-12 allaccount">
                 <span>OVERDUE: 0</span>
               </div>
               <div class="col-sm-12 allaccount">
                 <span>ZERO-BALANCE: 7</span>
               </div>
             </div>
           </div>
           <div class="col-sm-3 txtr">
           <span style="text-align: right;">HIGH CR/SANC. AMT: 1,73,187</span>
           </div>
           <div class="col-sm-3 txtr">
              <div class="row">
               <div class="col-sm-12 allaccount">
                 <span>TOTAL: 15</span>
               </div>
               <div class="col-sm-12 allaccount">
                 <span>OVERDUE: 0</span>
               </div>
               <div class="col-sm-12 allaccount">
                 <span>ZERO-BALANCE: 7</span>
               </div>
             </div>
           </div>
           <div class="col-sm-2 txtr">
             <div class="row">
               <div class="col-sm-12 allaccount">
                 <span>TOTAL: 15</span>
               </div>
               <div class="col-sm-12 allaccount">
                 <span>OVERDUE: 0</span>
               </div>
               <div class="col-sm-12 allaccount">
                 <span>ZERO-BALANCE: 7</span>
               </div>
             </div>
           </div>
         
        
          
         </div>
        </div>
      </div>
          <div class="col-sm-12">
        <div class="customer-detail-box">
          <h5>ENQUIRIES:</h5>
         <div class="row">
           <div class="col-sm-2">
             <p>ENQUIRY PURPOSE</p>
           </div>
          <div class="col-sm-2">
             <p>TOTAL</p>
           </div>
            <div class="col-sm-2">
             <p>PAST 30 DAYS</p>
           </div>
            <div class="col-sm-2">
             <p>PAST 12 MONTHS</p>
           </div>
            <div class="col-sm-2">
             <p>PAST 24 MONTHS</p>
           </div>
            <div class="col-sm-2">
             <p>RECENT</p>
           </div>
            
         </div>
        </div>
      </div>

<div class="col-sm-12" style="background-color:silver">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-2">
             <p>All Enquiries</p>
           </div>
           <div class="col-sm-2">
             <p>3</p>
           </div>
           <div class="col-sm-2">
             <p>5</p>
           </div>
           <div class="col-sm-2">
             <p>8</p>
           </div>
           <div class="col-sm-2">
             <p>0</p>
           </div>
           <div class="col-sm-2">
             <p>29-04-2024</p>
           </div>
        
          
         </div>
        </div>
      </div>
       <hr style="background-color: gray;height: 2px;margin-top: 30px;">

        <div class="col-sm-12">
        <div class="customer-detail-box">
          <h5>ACCOUNT(S):</h5>
        
        </div>
      </div>

<div class="col-sm-12" style="background-color:silver">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-3">
             <p>ACCOUNT</p>
             <div class="row">
               <div class="col-sm-12">
                 <span>MEMBER NAME</span>
                 <span>NOT DISCLOSED</span>
               </div>
                 <div class="col-sm-12">
                 <span>ACCOUNT NUMBER</span>
                 <span>NOT</span>
               </div>
                 <div class="col-sm-12">
                 <span>DISCLOSED</span>
                 <span></span>
               </div>
                 <div class="col-sm-12">
                 <span>TYPE:</span>
                 <span>OTHER</span>
               </div>
                  <div class="col-sm-12">
                 <span>OWNERSHIP:</span>
                 <span>INDIVIDUAL</span>
               </div>
             </div>
           </div>
           <div class="col-sm-3">
             <p>DATES</p>
                <div class="row">
               <div class="col-sm-12">
                 <span>OPENED</span>
                 <span>07-03-2024</span>
               </div>
                <div class="col-sm-12">
                 <span>REPORTED AND CERTIFIED:</span>
                 <span>31-03-2024</span>
               </div>
                <div class="col-sm-12">
                 <span>PMT HIST START</span>
                 <span> 01-03-2024</span>
               </div>
               <div class="col-sm-12">
                 <span>PMT HIST START</span>
                 <span> 01-03-2024</span>
               </div>
             </div>
           </div>
           <div class="col-sm-3">
             <p>AMOUNTS</p>
                <div class="row">
               <div class="col-sm-12">
                 <span>SANCTIONED:</span>
                 <span>17,000</span>
               </div>
               <div class="col-sm-12">
                 <span>CURRENT BALANCE:</span>
                 <span>13,222</span>
               </div>
               <div class="col-sm-12">
                 <span>PMT FREQ:</span>
                 <span>MONTHLY</span>
               </div>
             </div>
           </div>
           <div class="col-sm-3">
             <p>STATUS</p>
                <div class="row">
               <div class="col-sm-12">
                 <span>MEMBER NAME</span>
                 <span>NOT DISCLOSED</span>
               </div>
             </div>
           </div>
          <div class="col-sm-12">
            <span>DAYS PAST DUE/ASSET CLASSIFICATION (UP TO 36 MONTHS; LEFT TO RIGHT)</span>
            <div class="row">
              <div class="col-sm-1 pastdpd">
                <p>000</p>
                 <p>03-24</p>
              </div>
              <div class="col-sm-1">
                <p>000</p>
                 <p>03-24</p>
              </div>
              <div class="col-sm-1">
                <p>000</p>
                 <p>03-24</p>
              </div>
              <div class="col-sm-1">
                <p>000</p>
                 <p>03-24</p>
              </div>
              <div class="col-sm-1">
                <p>000</p>
                 <p>03-24</p>
              </div>
              <div class="col-sm-1">
                <p>000</p>
                 <p>03-24</p>
              </div>
              <div class="col-sm-1">
                <p>000</p>
                 <p>03-24</p>
              </div>
              <div class="col-sm-1">
                <p>000</p>
                 <p>03-24</p>
              </div>
              <div class="col-sm-1">
                <p>000</p>
                 <p>03-24</p>
              </div>
              <div class="col-sm-1">
                <p>000</p>
                 <p>03-24</p>
              </div>
              <div class="col-sm-1">
                <p>000</p>
                 <p>03-24</p>
              </div>
              <div class="col-sm-1">
                <p>000</p>
                 <p>03-24</p>
              </div>
            </div>
          </div>
         
          
         </div>
        </div>
      </div>
 <hr style="background-color: gray;height: 2px;margin-top: 30px;">

       <div class="col-sm-12">
        <div class="customer-detail-box">
          <h5>ENQUIRIES:</h5>
         <div class="row">
           <div class="col-sm-3">
             <p>MEMBER</p>
           </div>
          <div class="col-sm-3">
             <p>ENQUIRY DATE</p>
           </div>
            <div class="col-sm-3">
             <p>ENQUIRY PURPOSE</p>
           </div>
            <div class="col-sm-3">
             <p>ENQUIRY AMOUNT</p>
           </div>
         
            
         </div>
        </div>
      </div>

<div class="col-sm-12" style="background-color:silver">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-3">
             <p>NOT DISCLOSED</p>
           </div>
           <div class="col-sm-3">
             <p>29-04-2024</p>
           </div>
           <div class="col-sm-3">
             <p>CONSUMER LOAN </p>
           </div>
           <div class="col-sm-3">
             <p>35,000</p>
           </div>
        
        
          
         </div>
        </div>
      </div>
      <div class="col-sm-12">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-3">
             <p>NOT DISCLOSED</p>
           </div>
           <div class="col-sm-3">
             <p>29-04-2024</p>
           </div>
           <div class="col-sm-3">
             <p>CONSUMER LOAN </p>
           </div>
           <div class="col-sm-3">
             <p>35,000</p>
           </div>
        
        
          
         </div>
        </div>
      </div>
      <div class="col-sm-12" style="background-color:silver">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-3">
             <p>NOT DISCLOSED</p>
           </div>
           <div class="col-sm-3">
             <p>29-04-2024</p>
           </div>
           <div class="col-sm-3">
             <p>CONSUMER LOAN </p>
           </div>
           <div class="col-sm-3">
             <p>35,000</p>
           </div>
        
        
          
         </div>
        </div>
      </div>
      <div class="col-sm-12">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-3">
             <p>NOT DISCLOSED</p>
           </div>
           <div class="col-sm-3">
             <p>29-04-2024</p>
           </div>
           <div class="col-sm-3">
             <p>CONSUMER LOAN </p>
           </div>
           <div class="col-sm-3">
             <p>35,000</p>
           </div>
        
        
          
         </div>
        </div>
      </div>
      <div class="col-sm-12" style="background-color:silver">
        <div class="customer-detail-box">
         
         <div class="row">
           <div class="col-sm-3">
             <p>NOT DISCLOSED</p>
           </div>
           <div class="col-sm-3">
             <p>29-04-2024</p>
           </div>
           <div class="col-sm-3">
             <p>CONSUMER LOAN </p>
           </div>
           <div class="col-sm-3">
             <p>35,000</p>
           </div>
        
        
          
         </div>
        </div>
      </div>
       <hr style="background-color: gray;height: 2px;margin-top: 30px;">
         <div class="col-sm-12">
        <div class="customer-detail-box">
          <p>END OF REPORT ON SONIYADEVI</p>
        </div>
      </div>
       <hr style="background-color: gray;height: 2px;margin-top: 30px;">
        <div class="col-sm-12">
        <div class="customer-detail-box">
          <span>All information contained in this credit report has been collated by TransUnion CIBIL Limited ( TU CIBIL) based on information provided/ submitted by
its various members("Members"), as part of periodic data submission and Members are required to ensure accuracy, completeness and veracity of the
information submitted. The credit report is generated using the proprietary search and match logic of TU CIBIL. TU CIBIL uses its best efforts to ensure
accuracy, completeness and veracity of the information contained in the Report, and shall only be liable and / or responsible if any discrepancies are directly
attributable to TU CIBIL. The use of this report is governed by the terms and conditions of the Operating Rules for TU CIBIL and its Members.
</span>
        </div>
      </div>
    </div>
  </div>

  
</body>
</html>
